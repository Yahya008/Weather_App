package models

import java.io.Serializable

data class Place(
    val title:String,
    val Description:String,
    val latitude:Double,
    val longitude:Double
):Serializable