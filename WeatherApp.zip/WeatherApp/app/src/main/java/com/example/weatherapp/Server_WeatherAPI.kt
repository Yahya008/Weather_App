package com.example.weatherapp

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface Server_WeatherAPI {

    companion object{
        const val API_KEY="1117cd79cd9676785d468999ed167eb9"
    }


    @GET("?units=metric&appid=$API_KEY")
    fun getWeatherByCity(@Query("q") city:String): Call<WeatherRes>
}