package com.example.weatherapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI.setupActionBarWithNavController
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.gson.JsonObject
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.fragment_first_.*
import models.UserMap
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import com.example.weatherapp.*
import com.example.*
import models.Place

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [First_Fragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class First_Fragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    lateinit var ecityName:EditText
    lateinit var btnSearch:Button
    lateinit var imageWeather:ImageView
    lateinit var temperature:TextView
    lateinit var Cityname:TextView

    lateinit var lweather: LinearLayout

    private val TAG="First_Fragment"
    val EXTRA_USER_MAP="EXTRA_USER_MAP"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        val v = inflater.inflate(R.layout.fragment_first_, container, false)

        val btnNavView = v.findViewById<BottomNavigationView>(R.id.Btn_navigation)
        val navController = v.findNavController(R.id.Fragment)

        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.first_Fragment,
                R.id.second_Fragment,
                R.id.third_Fragment
            )
        )
        setupActionBarWithNavController(navController,appBarConfiguration)

        btnNavView.setupWithNavController(navController)

        ecityName = v.findViewById(R.id.editCity)
        btnSearch = v.findViewById(R.id.btnSearch)
        imageWeather = v.findViewById(R.id.imageWeather)
        temperature = v.findViewById(R.id.temp)
        Cityname = v.findViewById(R.id.CItyName)
        lweather = v.findViewById(R.id.WeatherLayout)

        btnSearch.setOnClickListener {
            val city = ecityName.text.toString()
            if (city.isEmpty()) {
                Toast.makeText( this,"City name can't be empty!!", Toast.LENGTH_SHORT).show()
            } else {
                getWeatherByCity(city)
            }
        }
        val userMaps=generateSampleData()
        //set layout manager on the recycler view
        rvMaps.layoutManager=LinearLayoutManager(this)
        //set adapter on the recycler view
        rvMaps.adapter=MapsAdapter(this, userMaps,object:MapsAdapter.OnClickListener{
            override fun onItemClick(position:Int){
                Log.i(TAG,"onItemClick $position")
                // When user taps on view,navigate to new activity
                val intent=Intent(this@First_Fragment, DisplayMapActivity::class.java)
                intent.putExtra(EXTRA_USER_MAP,userMaps[position])
               startActivity(intent)

            }
        })

        return v
    }
    private fun generateSampleData(): List<UserMap> {
        return listOf(
            UserMap(
                "Memories from University",
                listOf(
                    Place("Branner Hall", "Best dorm at Stanford", 37.426, -122.163),
                    Place("Gates CS building", "Many long nights in this basement", 37.430, -122.173),
                    Place("Pinkberry", "First date with my wife", 37.444, -122.170)
                )
            ),
            UserMap("January vacation planning!",
                listOf(
                    Place("Tokyo", "Overnight layover", 35.67, 139.65),
                    Place("Ranchi", "Family visit + wedding!", 23.34, 85.31),
                    Place("Singapore", "Inspired by \"Crazy Rich Asians\"", 1.35, 103.82)
                )),
            UserMap("Singapore travel itinerary",
                listOf(
                    Place("Gardens by the Bay", "Amazing urban nature park", 1.282, 103.864),
                    Place("Jurong Bird Park", "Family-friendly park with many varieties of birds", 1.319, 103.706),
                    Place("Sentosa", "Island resort with panoramic views", 1.249, 103.830),
                    Place("Botanic Gardens", "One of the world's greatest tropical gardens", 1.3138, 103.8159)
                )
            ),
            UserMap("My favorite places in the Midwest",
                listOf(
                    Place("Chicago", "Urban center of the midwest, the \"Windy City\"", 41.878, -87.630),
                    Place("Rochester, Michigan", "The best of Detroit suburbia", 42.681, -83.134),
                    Place("Mackinaw City", "The entrance into the Upper Peninsula", 45.777, -84.727),
                    Place("Michigan State University", "Home to the Spartans", 42.701, -84.482),
                    Place("University of Michigan", "Home to the Wolverines", 42.278, -83.738)
                )
            ),
            UserMap("Restaurants to try",
                listOf(
                    Place("Champ's Diner", "Retro diner in Brooklyn", 40.709, -73.941),
                    Place("Althea", "Chicago upscale dining with an amazing view", 41.895, -87.625),
                    Place("Shizen", "Elegant sushi in San Francisco", 37.768, -122.422),
                    Place("Citizen Eatery", "Bright cafe in Austin with a pink rabbit", 30.322, -97.739),
                    Place("Kati Thai", "Authentic Portland Thai food, served with love", 45.505, -122.635)
                )
            )
        )
    }
    fun getWeatherByCity(city: String)
    {
        //TODO1: create retrofit instance
        val retrofit= Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/data/2.5/weather/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val wService=retrofit.create(Server_WeatherAPI::class.java)


        //TODO2: call weather api
        val res = Server_WeatherAPI.getWeatherByCity(city)

        res.enqueue(object : Callback<WeatherRes> {
            override fun onResponse(call: Call<WeatherRes>, response: Response<WeatherRes>) {
                if(response.isSuccessful){
                    val res=response.body()
                    Picasso.get().load("https://openweathermap.org/img/w/${res?.weather?.get(0)?.icon}.png").into(imageWeather)
                    temperature.text="${res?.main?.temp} C"
                    Cityname.text=res?.name

                    lweather.visibility= View.VISIBLE

                }
            }

            override fun onFailure(call: Call<WeatherRes>, t: Throwable) {
                Toast.makeText(applicationContext,"Server error", Toast.LENGTH_SHORT).show()
            }

        })
    }
    companion object {
            /**
             * Use this factory method to create a new instance of
             * this fragment using the provided parameters.
             *
             * @param param1 Parameter 1.
             * @param param2 Parameter 2.
             * @return A new instance of fragment First_Fragment.
             */
            // TODO: Rename and change types and number of parameters
            @JvmStatic
            fun newInstance(param1: String, param2: String) =
                First_Fragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM1, param1)
                        putString(ARG_PARAM2, param2)
                    }
                }
    }
}